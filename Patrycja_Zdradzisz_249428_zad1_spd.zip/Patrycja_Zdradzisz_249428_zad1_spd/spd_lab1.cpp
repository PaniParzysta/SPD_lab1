﻿// spd_lab1.cpp : Ten plik zawiera funkcję „main”. W nim rozpoczyna się i kończy wykonywanie programu.
//

#include <iostream>
#include <fstream>

using namespace std;

//funkcja zliczająca sumę r, p, q
int cmax(int n, int* R, int* P, int* Q, int* X) {

	int m = 0, c = 0;

	for (int i = 0; i < n; i++) {

		m = max(m, R[X[i]]) + P[X[i]];
		c = max(c, m + Q[X[i]]);
	}
	return c;
}

//funkcja ustawiająca zadania w dość optymalnej kolejności
void kolejnosc(int n, int* R, int* P, int* Q, int* X) {

	for (int a = 0; a < n; a++)				//uzupenienie tablicy X
		X[a] = a;

	int dlugosc = cmax(n, R, P, Q, X), dlugosc_pom;

	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n - 1; j++) {

			swap(X[n - j - 1], X[n - j - 2]);				//bez tego ustawi zadania po kolei
			dlugosc_pom = cmax(n, R, P, Q, X);

			if (dlugosc_pom > dlugosc)
				swap(X[n - j - 1], X[n - j - 2]);

			else
				dlugosc = dlugosc_pom;
		}
	}
}

int main()
{
	int n, R[100], P[100], Q[100], X[100], wynik = 0;
	ifstream plik("dane.txt");
	string tab_string[4] = { "data.1","data.2","data.3","data.4" };

	for (int i = 0; i < 4; i++)
	{
		string string;
		while (string != tab_string[i])
			plik >> string;

		plik >> n;
		for (int i = 0; i < n; i++)
			plik >> R[i] >> P[i] >> Q[i];

		kolejnosc(n, R, P, Q, X);
		cout << "\nkolejnosc dla " << tab_string[i] << ":\n";

		for (int i = 0; i < n; i++)
			cout << X[i] + 1 << " ";

		cout << "\ncmax:" << cmax(n, R, P, Q, X) << endl;
		wynik += cmax(n, R, P, Q, X);
	}

	cout << endl;
	cout << "Suma wszystkich czasow: " << wynik;
	plik.close();
}

// Uruchomienie programu: Ctrl + F5 lub menu Debugowanie > Uruchom bez debugowania
// Debugowanie programu: F5 lub menu Debugowanie > Rozpocznij debugowanie

// Porady dotyczące rozpoczynania pracy:
//   1. Użyj okna Eksploratora rozwiązań, aby dodać pliki i zarządzać nimi
//   2. Użyj okna programu Team Explorer, aby nawiązać połączenie z kontrolą źródła
//   3. Użyj okna Dane wyjściowe, aby sprawdzić dane wyjściowe kompilacji i inne komunikaty
//   4. Użyj okna Lista błędów, aby zobaczyć błędy
//   5. Wybierz pozycję Projekt > Dodaj nowy element, aby utworzyć nowe pliki kodu, lub wybierz pozycję Projekt > Dodaj istniejący element, aby dodać istniejące pliku kodu do projektu
//   6. Aby w przyszłości ponownie otworzyć ten projekt, przejdź do pozycji Plik > Otwórz > Projekt i wybierz plik sln
